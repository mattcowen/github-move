# Description

**Type:** Distributed

This resource is used to configure Health Analyzer rules for the local farm.
The resource is able to enable/disable and configure the specified rule.
